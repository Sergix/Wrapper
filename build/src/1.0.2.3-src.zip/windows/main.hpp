#pragma once

#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <vector>
#include <windows.h>

#define NAME_SIZE 256
#define BUFFER_SIZE 131072