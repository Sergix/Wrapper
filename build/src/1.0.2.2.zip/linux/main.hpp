#pragma once

#include <sys/types.h>
#include <dirent.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include <string>
#include <vector>

#define NAME_SIZE 256
#define BUFFER_SIZE 131072